package DAO;

import Model.Curso;

public class CursoDAO {


    public void salvar(Curso curso) {

    }
}

