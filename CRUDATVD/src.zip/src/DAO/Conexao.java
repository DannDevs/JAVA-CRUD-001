package DAO;

public class Conexao {
}
