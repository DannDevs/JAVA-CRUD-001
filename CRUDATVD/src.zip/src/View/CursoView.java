package View;

import Controller.AlunoController;
import Controller.CursoController;
import Model.Curso;

import java.util.Scanner;

public class CursoView {

    public void menuCurso() {

        CursoController cursoController = new CursoController();
        Scanner input = new Scanner(System.in);
        int opcao = 0;

        do{
            System.out.println("=============");
            System.out.println("1 Cadastrar Curso");
            System.out.println("2 Consultar Curso ");
            System.out.println("3 Remover Curso");
            System.out.println("4 Atualizar Curso ");
            System.out.println("5 Voltar");
            System.out.println("=============");
            System.out.print("Opcao : ");
            opcao = input.nextInt();

            switch(opcao){
                case 1 ->{
                    System.out.println("Digite o CodCurso: ");
                    int idcurso = input.nextInt();
                    input.nextLine();
                    System.out.println("Digite o nome do curso");
                    String nome = input.nextLine();
                    System.out.println("Digite o Turno");
                    String turno = input.nextLine();
                    cursoController.cadastrarCurso(idcurso,nome,turno);
                }
                case 2 -> cursoController.consultarCursos();
                case 3 ->{}
                case 4 ->{}
                case 5 ->{
                    MenuView.menuExibir();
                }
                default ->  System.out.println("Opcao invalida");
            }
        } while (opcao != 0);
    }
}
