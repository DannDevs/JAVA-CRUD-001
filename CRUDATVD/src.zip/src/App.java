import View.MenuView;

public class App {

    public static void main(String[] args) {
        MenuView.menuExibir();
    }

}
