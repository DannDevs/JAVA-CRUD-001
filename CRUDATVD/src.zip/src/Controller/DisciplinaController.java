package Controller;

public class DisciplinaController {
}
