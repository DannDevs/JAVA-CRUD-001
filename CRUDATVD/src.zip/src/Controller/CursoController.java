package Controller;

import DAO.CursoDAO;
import Model.Curso;

import java.util.ArrayList;
import java.util.List;

public class CursoController {


    private static final List<Curso> cursos = new ArrayList<>();
    CursoDAO  cursoDAO = new CursoDAO();

    public void cadastrarCurso(int codcurso,String nomecurso,String turno) {

        if (validaCod(codcurso)) {
            System.out.println("Curso ja foi cadastrado");
            return;
        }
        if (validaNome(nomecurso)) {
            System.out.println("Nome invalido");
            return;
        }

        Curso novocurso =  new Curso(codcurso,nomecurso,turno);
        cursos.add(novocurso);
        cursoDAO.salvar(novocurso);
        System.out.println("Curso cadastrado com sucesso");

    }
    public void exibecoddisponiveis(){
        if(!cursos.isEmpty()){
            for(Curso c : cursos){
                System.out.println(c.getCodcurso());
            }
        }
        else {
            System.out.println(" ");
        }
    }

    public void consultarCursos(){
        if(!cursos.isEmpty()){
            for (Curso c : cursos) {
                System.out.println("Cod Curso: " + c.getCodcurso() );
                System.out.println("Nome Curso: " + c.getNomecurso() );
                System.out.println("Turno:" + c.getTurno() );
            }
        }
        else {
           System.out.println("Nao ha cursos disponiveis!");
        }
    }

    public Curso consultarcodigocurso(int codigo){
        for(Curso c : cursos){
            if (c.getCodcurso() == codigo){
                return c;
            }
        }
        return null;
    }


    public boolean validaCod(int codcurso){
            for(Curso c : cursos){
                if(c.getCodcurso() == codcurso){
                    return true;
                }
            }
        return false;
    }
    public boolean validaNome(String nome){
        return nome == null || nome.isEmpty();
    }

}
